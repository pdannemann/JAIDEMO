import { GoogleGenerativeAI } from '@google/generative-ai';

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);

export default async function handler(req, res) {
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method not allowed' });
    }

    try {
        const { text } = req.body;
        
        if (!text) {
            return res.status(400).json({ error: 'Text is required' });
        }

        const model = genAI.getGenerativeModel({
            model: "gemini-pro",
            generationConfig: {
                temperature: 0.1,
                topP: 0.1,
                topK: 1,
                maxOutputTokens: 2048,
            }
        });
        
        const result = await model.generateContent(text);
        const response = await result.response;
        
        return res.status(200).json({ result: response.text() });
    } catch (error) {
        console.error('Gemini API error:', error);
        return res.status(500).json({ error: error.message });
    }
}