class GeminiClient {
    async analyze(text) {
        if (!text || typeof text !== 'string') {
            throw new Error('Ungültiger Input: Text wird benötigt');
        }

        try {
            const response = await fetch('https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'x-goog-api-key': 'AIzaSyAjvFKCBiZvGyVYsz5_ejkzPVeLwQSmlDU'
                },
                body: JSON.stringify({
                    contents: [{
                        parts: [{
                            text: `Analysiere diese Nebenkostenabrechnung und erstelle eine umfassende Prüftabelle. Gib NUR ein JSON-Objekt in diesem exakten Format zurück:

{
    "totalSavings": "X €",
    "analysis": [
        {
            "point": "Name der Komponente/des Prüfpunkts",
            "status": "red/yellow/green",
            "problem": "Detaillierte Beschreibung des Problems oder der Korrektheit",
            "savings": "X €"
        }
    ]
}

KRITISCHE REGELN FÜR DIE STATUSVERGABE:

1. GRÜN (green):
   - Vollständige Dokumentation
   - Nachvollziehbare Berechnungen
   - Gesetzeskonforme Umsetzung
   - Marktübliche Preise

2. GELB (yellow):
   - Unvollständige Dokumentation
   - Unklare Berechnungen
   - Preise leicht über Durchschnitt
   - Rechtliche Unklarheiten

3. ROT (red):
   - Fehlende Dokumentation
   - Fehlerhafte Berechnungen
   - Gesetzesverstöße
   - Überhöhte Preise

PFLICHTKOMPONENTEN FÜR DIE ANALYSE:

1. Fristgerechte Erstellung
2. Grundsteuer
3. Wasserversorgung
4. Entwässerung
5. Heizkosten
6. Aufzug
7. Straßenreinigung
8. Müllbeseitigung
9. Hausreinigung
10. Hausmeister
11. Versicherungen
12. Allgemeinstrom

WICHTIG:
- Für jeden Punkt konkrete Daten angeben
- Bei 0 € Einsparung trotzdem Begründung
- Nur die angegebenen Status-Werte verwenden
- Keine zusätzlichen JSON-Felder hinzufügen

Hier ist die zu analysierende Nebenkostenabrechnung:
${text}`
                        }]
                    }],
                    generationConfig: {
                        temperature: 0.1,
                        topK: 1,
                        topP: 0.1,
                        maxOutputTokens: 2048,
                    }
                })
            });

            if (!response.ok) {
                const error = await response.json();
                console.error('API Error:', error);
                throw new Error('API-Anfrage fehlgeschlagen: ' + (error.error?.message || 'Unbekannter Fehler'));
            }

            const data = await response.json();
            if (!data.candidates?.[0]?.content?.parts?.[0]?.text) {
                console.error('Invalid API Response:', data);
                throw new Error('Ungültige API-Antwort: Keine Textdaten gefunden');
            }

            const result = data.candidates[0].content.parts[0].text.trim();
            
            // Find and clean JSON in the response
            const jsonMatch = result.match(/\{[\s\S]*\}/);
            if (!jsonMatch) {
                console.error('No JSON found in:', result);
                // Create a fallback response if no valid JSON is found
                return JSON.stringify({
                    totalSavings: "0 €",
                    analysis: [{
                        point: "Automatische Analyse",
                        status: "yellow",
                        problem: "Die Analyse konnte nicht vollständig durchgeführt werden. Bitte überprüfen Sie die Nebenkostenabrechnung manuell.",
                        savings: "0 €"
                    }]
                });
            }

            let jsonStr = jsonMatch[0];
            
            // Clean potential JSON issues
            jsonStr = jsonStr
                .replace(/,(\s*[}\]])/g, '$1') // Remove trailing commas
                .replace(/\u2018|\u2019/g, "'") // Replace smart quotes
                .replace(/\u201C|\u201D/g, '"') // Replace smart double quotes
                .replace(/[\u200B-\u200D\uFEFF]/g, ''); // Remove zero-width spaces

            let analysis;
            try {
                analysis = JSON.parse(jsonStr);
            } catch (e) {
                console.error('JSON Parse Error:', e, 'in:', jsonStr);
                // Return a fallback response if JSON parsing fails
                return JSON.stringify({
                    totalSavings: "0 €",
                    analysis: [{
                        point: "Automatische Analyse",
                        status: "yellow",
                        problem: "Die Analyse konnte nicht vollständig durchgeführt werden. Bitte überprüfen Sie die Nebenkostenabrechnung manuell.",
                        savings: "0 €"
                    }]
                });
            }
            
            // Ensure required structure exists
            if (!analysis.totalSavings) analysis.totalSavings = "0 €";
            if (!Array.isArray(analysis.analysis)) analysis.analysis = [];
            
            // If analysis array is empty, add a default item
            if (analysis.analysis.length === 0) {
                analysis.analysis.push({
                    point: "Automatische Analyse",
                    status: "yellow",
                    problem: "Die Analyse konnte nicht vollständig durchgeführt werden. Bitte überprüfen Sie die Nebenkostenabrechnung manuell.",
                    savings: "0 €"
                });
            }

            // Validate and fix each analysis item
            analysis.analysis = analysis.analysis.map(item => ({
                point: item.point || "Unbekannte Position",
                status: ['green', 'yellow', 'red'].includes(item.status) ? item.status : 'yellow',
                problem: item.problem || "Keine Details verfügbar",
                savings: item.savings || "0 €"
            }));

            return JSON.stringify(analysis);
        } catch (error) {
            console.error('Analysis Error:', error);
            // Return a fallback response for any other errors
            return JSON.stringify({
                totalSavings: "0 €",
                analysis: [{
                    point: "Automatische Analyse",
                    status: "yellow",
                    problem: "Die Analyse konnte nicht durchgeführt werden: " + (error.message || 'Unbekannter Fehler'),
                    savings: "0 €"
                }]
            });
        }
    }
}

export const geminiClient = new GeminiClient();